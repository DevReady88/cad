<?php 

/*###### PORTFOLIO CUSTOM POST ######*/

/* create the portfolio custom post */
function mediaconsult_custom_post_portfolio() {
	$labels = array(
		'name'               => esc_html__( 'Portfolio', 'post type general name', 'mediaconsult' ),
		'singular_name'      => esc_html__( 'Portfolio item', 'post type singular name', 'mediaconsult' ),
		'add_new'            => esc_html__( 'Add New', 'post', 'mediaconsult' ),
		'add_new_item'       => esc_html__( 'Add New Post', 'mediaconsult' ),
		'edit_item'          => esc_html__( 'Edit Portfolio Post', 'mediaconsult' ),
		'new_item'           => esc_html__( 'New Post', 'mediaconsult' ),
		'all_items'          => esc_html__( 'All Portfolio posts', 'mediaconsult' ),
		'view_item'          => esc_html__( 'View portfolio post', 'mediaconsult' ),
		'search_items'       => esc_html__( 'Search portfolio', 'mediaconsult' ),
		'not_found'          => esc_html__( 'No portfolio posts found', 'mediaconsult' ),
		'not_found_in_trash' => esc_html__( 'No portfolio posts found in the Trash', 'mediaconsult' ), 
		'parent_item_colon'  => '',
		'menu_name'          => esc_html__( 'Portfolio', 'mediaconsult' ),
	);
	$args = array(
		'labels'        => $labels,
		'description'   => esc_html__( 'Holds our portfolio specific data', 'mediaconsult' ),
		'public'        => true,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments', 'custom-fields' ),
		'has_archive'   => true,
		'rewrite'		=> array( 'slug' => 'portfolio' )	
	);
	register_post_type( 'portfolio', $args );
	
    flush_rewrite_rules();
}
add_action( 'init', 'mediaconsult_custom_post_portfolio' );



/* flush the permalinks */
function mediaconsult_portfolio_rewrite_flush() {
    mediaconsult_custom_post_portfolio();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'mediaconsult_portfolio_rewrite_flush' );



/* register portfolio taxonomy */
function mediaconsult_taxonomies_portfolio() {
	$labels = array(
		'name'              => esc_html__( 'Portfolio Categories', 'taxonomy general name', 'mediaconsult' ),
		'singular_name'     => esc_html__( 'Portfolio Category', 'taxonomy singular name', 'mediaconsult' ),
		'search_items'      => esc_html__( 'Search Portfolio Categories', 'mediaconsult' ),
		'all_items'         => esc_html__( 'All Portfolio Categories', 'mediaconsult' ),
		'parent_item'       => esc_html__( 'Parent Portfolio Category', 'mediaconsult' ),
		'parent_item_colon' => esc_html__( 'Parent Portfolio Category:', 'mediaconsult' ),
		'edit_item'         => esc_html__( 'Edit Portfolio Category', 'mediaconsult' ), 
		'update_item'       => esc_html__( 'Update Portfolio Category', 'mediaconsult' ),
		'add_new_item'      => esc_html__( 'Add New Portfolio Category', 'mediaconsult' ),
		'new_item_name'     => esc_html__( 'New Portfolio Category', 'mediaconsult' ),
		'menu_name'         => esc_html__( 'Portfolio Categories', 'mediaconsult' ),
	);
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	register_taxonomy( 'portfolio_category', 'portfolio', $args );
}
add_action( 'init', 'mediaconsult_taxonomies_portfolio', 0 );



/* here is a key-value array where the keys are used to reference certain post information */
function mediaconsult_portfolio_edit_columns($columns){
	$columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => esc_html__('Portfolio Title', 'mediaconsult'),
		"portfolio_desc" => esc_html__('Description', 'mediaconsult'),
		"portfolio_category" => esc_html__('Category', 'mediaconsult'),
		"portfolio_image" => esc_html__('Thumbnail', 'mediaconsult')						
	);
	return $columns;
}
add_filter("manage_edit-portfolio_columns", "mediaconsult_portfolio_edit_columns");



/* columns displayed for portfolio custom post */
function mediaconsult_portfolio_custom_columns($column){
	global $post;
	switch ($column)
	{
		case "portfolio_desc":
			echo the_excerpt();
			break;
		case "portfolio_category":
			echo get_the_term_list($post->ID, 'portfolio_category', '', ', ','');
			break;  
		case "portfolio_image":
			$custom = get_post_custom();
			the_post_thumbnail( 'mediaconsult_60x60-crop' );
			break;														
	}
}
add_action( "manage_posts_custom_column",  "mediaconsult_portfolio_custom_columns" );




/* define the portfolio meta box */
function mediaconsult_portfolio_meta_box() {
    add_meta_box( 
        'mediaconsult_portfolio_meta_box',
        esc_html__( 'Portfolio Post Options', 'mediaconsult' ),
        'mediaconsult_portfolio_meta_box_content',
        'portfolio',
        'advanced',
        'low'
    );
}
add_action( 'add_meta_boxes', 'mediaconsult_portfolio_meta_box' );




/* create the meta box contents */
function mediaconsult_portfolio_meta_box_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'mediaconsult_portfolio_meta_box_content_nonce' );
	
	$custom = get_post_custom($post->ID);

	$mc_video_link = '';
	$mc_port_related = '';	
	
	if ( isset( $custom["_mc_video_link"][0]) ) { 
		$mc_video_link = $custom["_mc_video_link"][0]; 
	}

	if ( isset( $custom["_mc_port_related"][0] ) ) { 
		$mc_port_related = $custom["_mc_port_related"][0];
	} else {
		$mc_port_related = 1; 		
	}
	?>
	
	<style type="text/css">
	.cel-customlist {
		list-style:none;
		margin: 0;
		padding: 0;	
	}
	.cel-customlist li {
		display:block;
		width: 100%;
		margin: 0 0 4px 0;	
	}
	.cel-input-large {
		position:relative;
		top: 2px;
		left: 2px;
		width: 56%;
	}
	.cel-customradio {
		position: relative;
		top: 2px;
	}
	@media only screen and (max-width: 800px) {
		.cel-input-large {
			width:80%;
		}		
	}
	@media only screen and (max-width: 480px) {
		.cel-input-large {
			width:100%;
			left:0;			
		}				
	}
    </style>
  	
	<ul class="gw-customlist">

		<li><p><?php esc_html_e( 'Do you wish to display related works on this particular post ?', 'mediaconsult' ); ?></p></li>
		<li>
			<input type="radio" id="mc_port_related_1" name="_mc_port_related"  value="1" <?php if ( $mc_port_related == 1 ) echo 'checked'; ?> class="cel-customradio" />
			<label for="mc_port_related_1"><?php esc_html_e( 'Yes', 'mediaconsult' ); ?></label>
		</li>
		<li>
			<input type="radio" id="mc_port_related_2" name="_mc_port_related"  value="2" <?php if ( $mc_port_related == 2 ) echo 'checked'; ?> class="cel-customradio" />
			<label for="mc_port_related_2"><?php esc_html_e( 'No', 'mediaconsult' ); ?></label>
		</li>        

	</ul>
    <?php
}


/* save meta data */
add_action( 'save_post', 'mediaconsult_portfolio_meta_box_save' );

function mediaconsult_portfolio_meta_box_save() {
	global $post;

	if( isset( $_POST["_mc_video_link"] ) )
	update_post_meta( $post->ID, "mc_video_link", $_POST["_mc_video_link"] );  

	if( isset( $_POST["_mc_port_related"] ) )
	update_post_meta( $post->ID, "_mc_port_related", $_POST["_mc_port_related"] );
}


?>