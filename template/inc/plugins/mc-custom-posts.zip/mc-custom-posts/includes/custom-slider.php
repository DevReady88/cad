<?php 

/*###### SLIDER CUSTOM POST ######*/

/* create the slider custom post */
function mediaconsult_custom_post_slider() {
	$labels = array(
		'name'               => esc_html__( 'Slider', 'post type general name', 'mediaconsult' ),
		'singular_name'      => esc_html__( 'Slider item', 'post type singular name', 'mediaconsult' ),
		'add_new'            => esc_html__( 'Add New', 'post', 'mediaconsult' ),
		'add_new_item'       => esc_html__( 'Add New Post', 'mediaconsult' ),
		'edit_item'          => esc_html__( 'Edit Slider Post', 'mediaconsult' ),
		'new_item'           => esc_html__( 'New Post', 'mediaconsult' ),
		'all_items'          => esc_html__( 'All Slider posts', 'mediaconsult' ),
		'view_item'          => esc_html__( 'View slider post', 'mediaconsult' ),
		'search_items'       => esc_html__( 'Search slider', 'mediaconsult' ),
		'not_found'          => esc_html__( 'No slider posts found', 'mediaconsult' ),
		'not_found_in_trash' => esc_html__( 'No slider posts found in the Trash', 'mediaconsult' ), 
		'parent_item_colon'  => '',
		'menu_name'          => esc_html__( 'Slider', 'mediaconsult' ),
	);
	$args = array(
		'labels'        => $labels,
		'description'   => esc_html__( 'Holds our slider specific data', 'mediaconsult' ),
		'public'        => true,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments', 'custom-fields' ),
		'has_archive'   => true,
		'rewrite'		=> array( 'slug' => 'slider' )	
	);
	register_post_type( 'slider', $args );
	
    flush_rewrite_rules();
}
add_action( 'init', 'mediaconsult_custom_post_slider' );



/* flush the permalinks */
function mediaconsult_slider_rewrite_flush() {
    mediaconsult_custom_post_slider();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'mediaconsult_slider_rewrite_flush' );



/* register slider taxonomy */
function mediaconsult_taxonomies_slider() {
	$labels = array(
		'name'              => esc_html__( 'Slider Categories', 'taxonomy general name', 'mediaconsult' ),
		'singular_name'     => esc_html__( 'Slider Category', 'taxonomy singular name', 'mediaconsult' ),
		'search_items'      => esc_html__( 'Search Slider Categories', 'mediaconsult' ),
		'all_items'         => esc_html__( 'All Slider Categories', 'mediaconsult' ),
		'parent_item'       => esc_html__( 'Parent Slider Category', 'mediaconsult' ),
		'parent_item_colon' => esc_html__( 'Parent Slider Category:', 'mediaconsult' ),
		'edit_item'         => esc_html__( 'Edit Slider Category', 'mediaconsult' ), 
		'update_item'       => esc_html__( 'Update Slider Category', 'mediaconsult' ),
		'add_new_item'      => esc_html__( 'Add New Slider Category', 'mediaconsult' ),
		'new_item_name'     => esc_html__( 'New Slider Category', 'mediaconsult' ),
		'menu_name'         => esc_html__( 'Slider Categories', 'mediaconsult' ),
	);
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	register_taxonomy( 'slider_category', 'slider', $args );
}
add_action( 'init', 'mediaconsult_taxonomies_slider', 0 );



/* here is a key-value array where the keys are used to reference certain post information */
function mediaconsult_slider_edit_columns( $columns ){
	$columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => esc_html__('Slider Title', 'mediaconsult'),
		"slider_desc" => esc_html__('Description', 'mediaconsult'),
		"slider_category" => esc_html__('Category', 'mediaconsult'),
		"slider_image" => esc_html__('Thumbnail', 'mediaconsult')						
	);
	return $columns;
}
add_filter( "manage_edit-slider_columns", "mediaconsult_slider_edit_columns" );



/* columns displayed for slider custom post */
function mediaconsult_slider_custom_columns($column){
	global $post;
	switch ($column)
	{
		case "slider_desc":
			echo the_excerpt();
			break;
		case "slider_category":
			echo get_the_term_list($post->ID, 'slider_category', '', ', ','');
			break;  
		case "slider_image":
			$custom = get_post_custom();
			the_post_thumbnail( 'mediaconsult_60x60-crop' );
			break;														
	}
}
add_action( "manage_posts_custom_column",  "mediaconsult_slider_custom_columns" );


?>