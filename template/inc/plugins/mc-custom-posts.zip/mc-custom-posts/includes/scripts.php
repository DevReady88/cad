<?php
/**
 * This file loads the CSS and JS necessary for your shortcodes display
 * @package IC Custom Posts Plugin
 * @since 1.0
 * @author Celestial Themes : http://celestialthemes.com
 * @copyright Copyright (c) 2017, Celestial Themes
 * @link http://celestialthemes.com
 * @License: GNU General Public License version 2.0
 * @License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */
 

if( !function_exists ('innovaconstruct_custom_posts_scripts') ) :
	function innovaconstruct_custom_posts_scripts() {
	
		if ( is_page_template( 'template-portfolio_3col.php' ) || is_page_template( 'template-portfolio_4col.php' )
		|| is_page_template( 'template-portfolio_1col.php' ) || is_tax() ) {
			
			
			//wp_enqueue_script( 'imagesloaded' );
			
			//wp_register_script( 'innovaconstruct_isotope', plugin_dir_url( __FILE__ ) . 'js/jquery.isotope.min.js', array('jquery'), false, true );
			//wp_enqueue_script( 'innovaconstruct_isotope' );
			
			
			
			//wp_register_script( 'innovaconstruct_isotope-call', plugin_dir_url( __FILE__ ) . 'js/jquery.isotope.call.js', array( 'jquery', 'innovaconstruct_libraries-js' ), false, true );
			//wp_enqueue_script( 'innovaconstruct_isotope-call' );
		
			/*
			wp_register_script( 'innovaconstruct_equalheight', plugin_dir_url( __FILE__ ) . 'js/jquery.equalheight.js', array('jquery'), false, true );
			wp_enqueue_script( 'innovaconstruct_equalheight' );
			
			
			wp_register_script( 'innovaconstruct_equalheight-call', plugin_dir_url( __FILE__ ) . 'js/jquery.equalheight.call.js', array('jquery'), false, true);
			wp_enqueue_script('innovaconstruct_equalheight-call');
			*/
			
			wp_register_script( 'magnific-popup', plugin_dir_url( __FILE__ ) . 'js/jquery.magnific-popup.min.js', array('jquery'), false, true );
			wp_enqueue_script( 'magnific-popup' );
		}
			
	
	}
	add_action( 'wp_enqueue_scripts', 'innovaconstruct_custom_posts_scripts' );
endif;



/* load plugin localization */
if( !function_exists ( 'innovaconstruct_custom_posts_load_textdomain' ) ) :
	
	function innovaconstruct_custom_posts_load_textdomain() {
		load_plugin_textdomain( 'ic-custom-posts', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
	}
	
	add_action( 'plugins_loaded', 'innovaconstruct_custom_posts_load_textdomain' );
	
endif;