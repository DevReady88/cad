<?php 

/*###### PORTFOLIO CUSTOM POST ######*/

/* create the ressources custom post */
function mediaconsult_custom_post_ressources() {
	$labels = array(
		'name'               => esc_html__( 'Ressources', 'post type general name', 'mediaconsult' ),
		'singular_name'      => esc_html__( 'Ressources item', 'post type singular name', 'mediaconsult' ),
		'add_new'            => esc_html__( 'Add New', 'post', 'mediaconsult' ),
		'add_new_item'       => esc_html__( 'Add New Post', 'mediaconsult' ),
		'edit_item'          => esc_html__( 'Edit Ressources Post', 'mediaconsult' ),
		'new_item'           => esc_html__( 'New Post', 'mediaconsult' ),
		'all_items'          => esc_html__( 'All Ressources posts', 'mediaconsult' ),
		'view_item'          => esc_html__( 'View ressources post', 'mediaconsult' ),
		'search_items'       => esc_html__( 'Search ressources', 'mediaconsult' ),
		'not_found'          => esc_html__( 'No ressources posts found', 'mediaconsult' ),
		'not_found_in_trash' => esc_html__( 'No ressources posts found in the Trash', 'mediaconsult' ), 
		'parent_item_colon'  => '',
		'menu_name'          => esc_html__( 'Ressources', 'mediaconsult' ),
	);
	$args = array(
		'labels'        => $labels,
		'description'   => esc_html__( 'Holds our ressources specific data', 'mediaconsult' ),
		'public'        => true,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments', 'custom-fields' ),
		'has_archive'   => true,
		'rewrite'		=> array( 'slug' => 'ressources' )	
	);
	register_post_type( 'ressources', $args );
	
    flush_rewrite_rules();
}
add_action( 'init', 'mediaconsult_custom_post_ressources' );



/* flush the permalinks */
function mediaconsult_ressources_rewrite_flush() {
    mediaconsult_custom_post_ressources();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'mediaconsult_ressources_rewrite_flush' );



/* register ressources taxonomy */
function mediaconsult_taxonomies_ressources() {
	$labels = array(
		'name'              => esc_html__( 'Ressources Categories', 'taxonomy general name', 'mediaconsult' ),
		'singular_name'     => esc_html__( 'Ressources Category', 'taxonomy singular name', 'mediaconsult' ),
		'search_items'      => esc_html__( 'Search Ressources Categories', 'mediaconsult' ),
		'all_items'         => esc_html__( 'All Ressources Categories', 'mediaconsult' ),
		'parent_item'       => esc_html__( 'Parent Ressources Category', 'mediaconsult' ),
		'parent_item_colon' => esc_html__( 'Parent Ressources Category:', 'mediaconsult' ),
		'edit_item'         => esc_html__( 'Edit Ressources Category', 'mediaconsult' ), 
		'update_item'       => esc_html__( 'Update Ressources Category', 'mediaconsult' ),
		'add_new_item'      => esc_html__( 'Add New Ressources Category', 'mediaconsult' ),
		'new_item_name'     => esc_html__( 'New Ressources Category', 'mediaconsult' ),
		'menu_name'         => esc_html__( 'Ressources Categories', 'mediaconsult' ),
	);
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	register_taxonomy( 'ressources_category', 'ressources', $args );
}
add_action( 'init', 'mediaconsult_taxonomies_ressources', 0 );



/* here is a key-value array where the keys are used to reference certain post information */
function mediaconsult_ressources_edit_columns($columns){
	$columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => esc_html__('Ressources Title', 'mediaconsult'),
		"ressources_desc" => esc_html__('Description', 'mediaconsult'),
		"ressources_category" => esc_html__('Category', 'mediaconsult'),
		"ressources_image" => esc_html__('Thumbnail', 'mediaconsult')						
	);
	return $columns;
}
add_filter("manage_edit-ressources_columns", "mediaconsult_ressources_edit_columns");



/* columns displayed for ressources custom post */
function mediaconsult_ressources_custom_columns($column){
	global $post;
	switch ($column)
	{
		case "pressources_desc":
			echo the_excerpt();
			break;
		case "ressources_category":
			echo get_the_term_list($post->ID, 'ressources_category', '', ', ','');
			break;  
		case "ressources_image":
			$custom = get_post_custom();
			the_post_thumbnail( 'mediaconsult_60x60-crop' );
			break;														
	}
}
add_action( "manage_posts_custom_column",  "mediaconsult_ressources_custom_columns" );




/* define the ressources meta box */
function mediaconsult_ressources_meta_box() {
    add_meta_box( 
        'mediaconsult_ressources_meta_box',
        esc_html__( 'Ressources Post Options', 'mediaconsult' ),
        'mediaconsult_ressources_meta_box_content',
        'ressources',
        'advanced',
        'low'
    );
}
add_action( 'add_meta_boxes', 'mediaconsult_ressources_meta_box' );




/* create the meta box contents */
function mediaconsult_ressources_meta_box_content( $post ) {
	wp_nonce_field( plugin_basename( __FILE__ ), 'mediaconsult_ressources_meta_box_content_nonce' );
	
	$custom = get_post_custom( $post->ID );

	$mc_ressource_download_link = '';
	$mc_ressource_post_detail = '';
	$mc_ressource_related = '';
	$mc_ressource_format = '';
	$mc_ressource_size = '';
	
	if ( isset( $custom["_mc_ressource_download_link"][0]) ) { 
		$mc_ressource_download_link = $custom["_mc_ressource_download_link"][0]; 
	}

	if ( isset( $custom["_mc_ressource_format"][0]) ) { 
		$mc_ressource_format = $custom["_mc_ressource_format"][0]; 
	}	

	if ( isset( $custom["_mc_ressource_size"][0]) ) { 
		$mc_ressource_size = $custom["_mc_ressource_size"][0]; 
	}	
	
	if ( isset( $custom["_mc_ressource_post_detail"][0]) ) { 
		$mc_ressource_post_detail = $custom["_mc_ressource_post_detail"][0]; 
	} else {
		$mc_ressource_post_detail = 2;
	}
	
	if ( isset( $custom["_mc_ressource_related"][0] ) ) { 
		$mc_ressource_related = $custom["_mc_ressource_related"][0];
	} else {
		$mc_ressource_related = 1; 		
	}
	?>
	
	<style type="text/css">
	.cel-customlist {
		list-style: none;
		margin: 0;
		padding: 0;	
	}
	.cel-customlist li {
		display: block;
		width: 100%;
		margin: 4px 0;
	}
	.cel-customlist li input[type="text"] {
		height: 32px;
	}
	.cel-customlist li p {
		margin: 6px 0;
	}
	.cel-input-large {
		position: relative;
		top: 2px;
		left: 2px;
		width: 56%;
	}
	.cel-customradio {
		position: relative;
		top: 2px;
	}
	.cel-customlist .cel-top-margin-list {
		margin-top: 22px;
	}
	@media only screen and (max-width: 800px) {
		.cel-input-large {
			width: 80%;
		}		
	}
	@media only screen and (max-width: 480px) {
		.cel-input-large {
			width: 100%;
			left: 0;			
		}				
	}
    </style>
  	
	<ul class="cel-customlist">


		<li class="cel-top-margin-list"><label for="_mc_ressource_download_link"><?php esc_html_e( 'Ressource Download Link', 'mediaconsult' ); ?></label></li>
		<li>
			<input type="text" id="_mc_ressource_download_link" name="_mc_ressource_download_link" class="cel-input-large" value="<?php echo esc_html( $mc_ressource_download_link ); ?>" />
		</li>


		<li class="cel-top-margin-list"><label for="_mc_ressource_format"><?php esc_html_e( 'Ressource Format(PDF, XLS, DOC, etc)', 'mediaconsult' ); ?></label></li>
		<li>
			<input type="text" id="_mc_ressource_format" name="_mc_ressource_format" class="cel-input-large" value="<?php echo esc_html( $mc_ressource_format ); ?>" />
		</li>
		
		
		<li class="cel-top-margin-list"><label for="_mc_ressource_size"><?php esc_html_e( 'Ressource Size', 'mediaconsult' ); ?></label></li>
		<li>
			<input type="text" id="_mc_ressource_size" name="_mc_ressource_size" class="cel-input-large" value="<?php echo esc_html( $mc_ressource_size ); ?>" />
		</li>		
		
		
		<li class="cel-top-margin-list">
			<p><?php esc_html_e( 'Has Post Detail ?', 'mediaconsult' ); ?></p>
		</li>
		<li>
			<input type="radio" id="mc_ressource_post_detail_1" name="_mc_ressource_post_detail"  value="1" <?php if ( $mc_ressource_post_detail == 1 ) echo 'checked'; ?> class="cel-customradio" />
			<label for="mc_ressource_post_detail_1"><?php esc_html_e( 'Yes', 'mediaconsult' ); ?></label>
		</li>
		<li>
			<input type="radio" id="mc_ressource_post_detail_2" name="_mc_ressource_post_detail"  value="2" <?php if ( $mc_ressource_post_detail == 2 ) echo 'checked'; ?> class="cel-customradio" />
			<label for="mc_ressource_post_detail_2"><?php esc_html_e( 'No', 'mediaconsult' ); ?></label>
		</li> 
		
		<!--
		<li class="cel-top-margin-list">
			<p><?php //esc_html_e( 'Display Related Ressources For This Post ?', 'mediaconsult' ); ?></p>
		</li>
		<li>
			<input type="radio" id="mc_ressource_related_1" name="_mc_ressource_related"  value="1" <?php //if ( $mc_ressource_related == 1 ) echo 'checked'; ?> class="cel-customradio" />
			<label for="mc_ressource_related_1"><?php //esc_html_e( 'Yes', 'mediaconsult' ); ?></label>
		</li>
		<li>
			<input type="radio" id="mc_ressource_related_2" name="_mc_ressource_related"  value="2" <?php //if ( $mc_ressource_related == 2 ) echo 'checked'; ?> class="cel-customradio" />
			<label for="mc_ressource_related_2"><?php //esc_html_e( 'No', 'mediaconsult' ); ?></label>
		</li>      
		-->

	</ul>
    <?php
}


/* save meta data */
add_action( 'save_post', 'mediaconsult_ressources_meta_box_save' );

function mediaconsult_ressources_meta_box_save() {
	global $post;

	if( isset( $_POST["_mc_ressource_download_link"] ) )
	update_post_meta( $post->ID, "_mc_ressource_download_link", $_POST["_mc_ressource_download_link"] ); 
	
	if( isset( $_POST["_mc_ressource_format"] ) )
	update_post_meta( $post->ID, "_mc_ressource_format", $_POST["_mc_ressource_format"] );  
	
	if( isset( $_POST["_mc_ressource_size"] ) )
	update_post_meta( $post->ID, "_mc_ressource_size", $_POST["_mc_ressource_size"] );  
	
	if( isset( $_POST["_mc_ressource_post_detail"] ) )
	update_post_meta( $post->ID, "_mc_ressource_post_detail", $_POST["_mc_ressource_post_detail"] );  

	if( isset( $_POST["_mc_ressource_related"] ) )
	update_post_meta( $post->ID, "_mc_ressource_related", $_POST["_mc_ressource_related"] );
}


?>