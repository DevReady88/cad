<?php
/*
Plugin Name: MC Custom Posts
Plugin URI: http://www.celestialthemes.com
Description: Media Consult Custom Posts Plugin
Author: Celestial Themes
Author URI: http://www.celestialthemes.com
Version: 1.0
License: GNU General Public License version 2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// Adds plugin JS and CSS
require_once( dirname(__FILE__) . '/includes/scripts.php' );

// Include the custom portfolio
require_once( dirname(__FILE__) . '/includes/custom-portfolio.php' );

// Include the custom slider
require_once( dirname(__FILE__) . '/includes/custom-slider.php' );

// Include the custom ressources
require_once( dirname(__FILE__) . '/includes/custom-ressources.php' );