<?php



/* ========= CREATE META BOXES ========= */
function mediaconsult_add_custom_box() {
    
	global $post;
	
    $screens = ['page'];
	
	
    foreach( $screens as $screen ) {
        add_meta_box(
            'mediaconsult_page-parameters',
			esc_html__( 'Page Parameters', 'mediaconsult' ),
            'mediaconsult_page_parameters_output',
            $screen                   
        );
    }
	
	
	if( !empty( $post ) ) {
		
		if ( 'template-blog.php' == get_post_meta( $post->ID, '_wp_page_template', true ) ) {
			add_meta_box(
				'mediaconsult_posts-category',         
				esc_html__( 'Blog Custom Options', 'mediaconsult' ),
				'mediaconsult_posts_category_output',
				'page'
			);			
		}
		
	}


	if( !empty( $post ) ) {
		
		if ( 'template-ressources.php' == get_post_meta( $post->ID, '_wp_page_template', true ) ) {
			add_meta_box(
				'mediaconsult_ressources-category',         
				esc_html__( 'Ressources Parameters', 'mediaconsult' ),
				'mediaconsult_ressources_category_output',
				'page'
			);			
		}
		
	}
	
	
	if( !empty( $post ) ) {
		
		if ( 'template-portfolio.php' == get_post_meta( $post->ID, '_wp_page_template', true ) ) {
			add_meta_box(
				'mediaconsult_portfolio-category',         
				esc_html__( 'Portfolio Parameters', 'mediaconsult' ),
				'mediaconsult_portfolio_parameters_output',
				'page'
			);
		}
		
	}
	
	
}
add_action( 'add_meta_boxes', 'mediaconsult_add_custom_box' );




/* ========= DEFAULT PAGE META BOX HTML OUTPUT ========= */
function mediaconsult_page_parameters_output( $post ) { ?>
    
    
    <!-- display page title -->
    <?php $page_title_key_value = get_post_meta( $post->ID, '_mediaconsult_display_page_title', true ); ?>
    
    <label for="mc_display_page_title"><?php esc_html_e( 'Display Page Title ?', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_display_page_title" id="mc_display_page_title" class="postbox">
        <option value="yes" <?php selected( $page_title_key_value, 'yes' ); ?>>
        	<?php esc_html_e( 'Yes', 'mediaconsult' ); ?>
        </option>
        <option value="no" <?php selected( $page_title_key_value, 'no' ); ?>>
        	<?php esc_html_e( 'No', 'mediaconsult' ); ?>
        </option>
    </select>
    
    <br />
    
    
    
    <!-- custom page title -->
    <?php $mediaconsult_page_title = get_post_meta( $post->ID, '_mediaconsult_page_title', true ); ?>
    
    <label for="mc_page_title"><?php esc_html_e( 'Custom Page Title Content', 'mediaconsult' ); ?></label><br /><br />
    
    <textarea name="mc_page_title" id="mc_page_title" class="widefat" rows="8"><?php echo esc_html( $mediaconsult_page_title, 'mediaconsult' ); ?></textarea>
    
    <br /><br />
    
    
    
    <!-- display sidebar - exclude blog, portfolio and ressources templates -->
    <?php $display_sidebar_key_value = get_post_meta( $post->ID, '_mediaconsult_display_sidebar', true ); ?>
    
    <?php if ( ( 'template-blog.php' != get_post_meta( $post->ID, '_wp_page_template', true ) ) && ( 'template-portfolio.php' != get_post_meta( $post->ID, '_wp_page_template', true ) ) && ( 'template-ressources.php' != get_post_meta( $post->ID, '_wp_page_template', true ) ) ) { ?>
    
		<label for="mc_display_sidebar"><?php esc_html_e( 'Enable Sidebar ?', 'mediaconsult' ); ?></label><br /><br />

		<select name="mc_display_sidebar" id="mc_display_sidebar" class="postbox">
		
			<option value="yes" <?php selected( $display_sidebar_key_value, 'yes' ); ?>>
				<?php esc_html_e( 'Yes', 'mediaconsult' ); ?>
			</option>
			
			<option value="no" <?php selected( $display_sidebar_key_value, 'no' ); ?>>
				<?php esc_html_e( 'No', 'mediaconsult' ); ?>
			</option>
			
		</select>
    
    <?php } ?>
          
    <br />
    
    
    
    <!-- sidebar position - exclude portfolio template -->
    <?php $sidebar_position_key_value = get_post_meta( $post->ID, '_mediaconsult_sidebar_position', true ); ?>
    
    <?php if ( 'template-portfolio.php' != get_post_meta( $post->ID, '_wp_page_template', true ) ) { ?>
    
		<label for="mc_sidebar_position"><?php esc_html_e( 'Sidebar Alignment', 'mediaconsult' ); ?></label><br /><br />

		<select name="mc_sidebar_position" id="mc_sidebar_position" class="postbox">
		
			<option value="right" <?php selected( $sidebar_position_key_value, 'right' ); ?>>
				<?php esc_html_e( 'Right', 'mediaconsult' ); ?>
			</option>
			
			<option value="left" <?php selected( $sidebar_position_key_value, 'left' ); ?>>
				<?php esc_html_e( 'Left', 'mediaconsult' ); ?>
			</option>
			
		</select>
    
    <?php } ?>
    
    <br />         
          
          
          
    <!-- display slider -->
    <?php $display_slider_key_value = get_post_meta( $post->ID, '_mediaconsult_display_slider', true ); ?>
    
    <label for="mc_display_slider"><?php esc_html_e( 'Display Slider ?', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_display_slider" id="mc_display_slider" class="postbox">
       
        <option value="no" <?php selected( $display_slider_key_value, 'no' ); ?>>
        	<?php esc_html_e( 'No', 'mediaconsult' ); ?>
        </option>
               
        <option value="yes" <?php selected( $display_slider_key_value, 'yes' ); ?>>
        	<?php esc_html_e( 'Yes', 'mediaconsult' ); ?>
        </option>

    </select>
          
    <br />
            
       
       
    <!-- slider type -->
    <?php $slider_type_key_value = get_post_meta( $post->ID, '_mediaconsult_slider_type', true ); ?>
    
    <label for="mc_slider_type"><?php esc_html_e( 'Choose the slider(section) layout', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_slider_type" id="mc_slider_type" class="postbox">
       
        <option value="default" <?php selected( $slider_type_key_value, 'default' ); ?>>
        	<?php esc_html_e( 'Default Slider Posts', 'mediaconsult' ); ?>
        </option>
               
        <option value="latest_blog_posts_classic" <?php selected( $slider_type_key_value, 'latest_blog_posts_classic' ); ?>>
        	<?php esc_html_e( 'Latest Blog Posts', 'mediaconsult' ); ?>
        </option>
           
    </select>
           
    <br />
    
       
       
    <!-- slider blog posts category -->
    <?php $slider_posts_category_key_value = get_post_meta( $post->ID, '_mediaconsult_slider_posts_category', true ); ?>
    
    <label for="mc_slider_posts_category"><?php esc_html_e( 'Slider Blog Posts Category', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_slider_posts_category" id="mc_slider_posts_category" class="postbox">
       
		<?php $all_categories = get_categories( 'orderby=name' );
			
			echo "<option value='' " . selected( $slider_posts_category_key_value, '' ) . ">" . esc_html__( 'All', 'mediaconsult' ) . "</option>\n";
	
			foreach( $all_categories as $category ) {

				echo "<option value='" . $category->slug . "' " . selected( $slider_posts_category_key_value, $category->slug ) . ">" . $category->cat_name . "</option>\n";

			}

		?>

    </select>
                                                                                                                                 
    <?php
	
}




/* ========= BLOG POSTS CATEGORY META BOX HTML OUTPUT ========= */
function mediaconsult_posts_category_output( $post ) {
	
    $key_value = get_post_meta( $post->ID, '_mediaconsult_blog_cat', true ); ?>
    
    
    <!-- filter posts by category -->
    <label for="mc_posts_category"><?php esc_html_e( 'Choose A Category To Filter Your Blog Posts', 'mediaconsult' ); ?></label><br /><br />
    
	<select name="mc_posts_category" id="mc_posts_category" class="postbox">                       

		<?php $all_categories = get_categories( 'orderby=name' );
			
			echo "<option value='' " . selected( $key_value, '' ) . ">" . esc_html__( 'All', 'mediaconsult' ) . "</option>\n";
	
			foreach( $all_categories as $category ) {

				echo "<option value='" . $category->slug . "' " . selected( $key_value, $category->slug ) . ">" . $category->cat_name . "</option>\n";

			}

		?>

	</select>
    
    <br />

   
    <!-- display post filters -->
    <?php $post_filters_key_value = get_post_meta( $post->ID, '_mediaconsult_display_post_filters', true ); ?>
    
    <label for="mc_display_post_filters"><?php esc_html_e( 'Display Top Filter Section Area On Posts Listing ?', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_display_post_filters" id="mc_display_post_filters" class="postbox">
        <option value="yes" <?php selected( $post_filters_key_value, 'yes' ); ?>>
        	<?php esc_html_e( 'Yes', 'mediaconsult' ); ?>
        </option>
        <option value="no" <?php selected( $post_filters_key_value, 'no' ); ?>>
        	<?php esc_html_e( 'No', 'mediaconsult' ); ?>
        </option>
    </select>
    
    <br />
      
       
    <!-- posts layout -->
    <?php $post_layout_key_value = get_post_meta( $post->ID, '_mediaconsult_post_layout', true ); ?>
    
    <label for="mc_post_layout"><?php esc_html_e( 'Blog Posts Layout', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_post_layout" id="mc_post_layout" class="postbox">
        <option value="default" <?php selected( $post_layout_key_value, 'default' ); ?>>
        	<?php esc_html_e( 'Default', 'mediaconsult' ); ?>
        </option>
        <option value="3_columns_no_sidebar" <?php selected( $post_layout_key_value, '3_columns_no_sidebar' ); ?>>
        	<?php esc_html_e( '3 Columns No Sidebar', 'mediaconsult' ); ?>
        </option>
        <option value="list_small" <?php selected( $post_layout_key_value, 'list_small' ); ?>>
        	<?php esc_html_e( 'Small Listing', 'mediaconsult' ); ?>
        </option>        
    </select>
                 
    <?php
}

	
	
	

/* ========= RESSOURCES CATEGORY META BOX HTML OUTPUT ========= */
function mediaconsult_ressources_category_output( $post ) {
	
    $key_value = get_post_meta( $post->ID, '_mediaconsult_ressources_cat', true ); ?>
    

    <!-- filter ressources by category -->
    <label for="mc_ressources_category"><?php esc_html_e( 'Choose A Category To Filter Your Ressources', 'mediaconsult' ); ?></label><br /><br />

	<?php echo mediaconsult_taxonomies_dropdown( 'ressources', 'ressources_category', 'mc_ressources_category', esc_html__( 'Ressource Type', 'mediaconsult' ), $key_value, 'postbox' ); ?>
    
    <br />

   
    <!-- display ressources filters -->
    <?php $post_filters_key_value = get_post_meta( $post->ID, '_mediaconsult_display_ressources_filters', true ); ?>
    
    <label for="mc_display_ressources_filters"><?php esc_html_e( 'Display Top Filter Section Area On Ressources Listing ?', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_display_ressources_filters" id="mc_display_ressources_filters" class="postbox">
        <option value="yes" <?php selected( $post_filters_key_value, 'yes' ); ?>>
        	<?php esc_html_e( 'Yes', 'mediaconsult' ); ?>
        </option>
        <option value="no" <?php selected( $post_filters_key_value, 'no' ); ?>>
        	<?php esc_html_e( 'No', 'mediaconsult' ); ?>
        </option>
    </select>
    
    <br />
      
    
    <!-- ressources layout -->
    <?php $post_layout_key_value = get_post_meta( $post->ID, '_mediaconsult_ressource_layout', true ); ?>
    
    <label for="mc_ressources_layout"><?php esc_html_e( 'Ressources Template Layout', 'mediaconsult' ); ?></label><br /><br />
    
    <select name="mc_ressources_layout" id="mc_ressources_layout" class="postbox">
        <option value="default" <?php selected( $post_layout_key_value, 'default' ); ?>>
        	<?php esc_html_e( 'Default', 'mediaconsult' ); ?>
        </option>
        <option value="minimal" <?php selected( $post_layout_key_value, 'minimal' ); ?>>
        	<?php esc_html_e( 'Minimal', 'mediaconsult' ); ?>
        </option>      
    </select>
                 
    <?php
}




/* ========= PORTFOLIO POSTS CATEGORY META BOX HTML OUTPUT ========= */
function mediaconsult_portfolio_parameters_output( $post ) { ?>
	
    
    <!-- Portfolio Category -->
    <?php $port_cat_key_value = get_post_meta( $post->ID, '_mediaconsult_port_cat', true ); ?>
    
    <label for="mc_portfolio_category"><?php esc_html_e( 'Choose A Category To Filter Your Portfolio Posts', 'mediaconsult' ); ?></label><br /><br />
    
	<select name="mc_portfolio_category" id="mc_portfolio_category" class="postbox">

		<?php $all_categories = get_categories( 'title_li=&order=asc&hide_empty=0&taxonomy=portfolio_category' );

			foreach( $all_categories as $category ) {

				echo "<option value='" . $category->slug . "' " . selected( $port_cat_key_value, $category->slug ) . ">" . $category->name . "</option>\n";
				
			} 
		?>

	</select>
   
    <br />
    
    
    <!-- Display Portfolio Categories -->
    <?php $display_port_category_key_value = get_post_meta( $post->ID, '_mediaconsult_display_port_cat', true ); ?>
    
	<label for="mc_display_cat"><?php esc_html_e( 'Display Portfolio Categories In The Post Listing ?', 'mediaconsult' ); ?></label><br /><br />

	<select name="mc_display_cat" id="mc_display_cat" class="postbox">
		
		<option value="yes" <?php selected( $display_port_category_key_value, 'yes' ); ?>>
			<?php esc_html_e( 'Yes', 'mediaconsult' ); ?>
		</option>

		<option value="no" <?php selected( $display_port_category_key_value, 'no' ); ?>>
			<?php esc_html_e( 'No', 'mediaconsult' ); ?>
		</option>
					
	</select>
   
    <br />              
    
                  
    <!-- Portfolio Columns -->
    <?php $port_columns_key_value = get_post_meta( $post->ID, '_mediaconsult_port_columns', true ); ?>
	
	<label for="mc_port_columns"><?php esc_html_e( 'Portfolio Layout Columns', 'mediaconsult' ); ?></label><br /><br />

	<select name="mc_port_columns" id="mc_port_columns" class="postbox">
	
		<option value="2" <?php selected( $port_columns_key_value, '2' ); ?>>
			<?php esc_html_e( '2', 'mediaconsult' ); ?>
		</option>
		
		<option value="3" <?php selected( $port_columns_key_value, '3' ); ?>>
			<?php esc_html_e( '3', 'mediaconsult' ); ?>
		</option>
		
	</select>
    
    
    <?php
}



/* ========= SAVE META BOXES VALUES ========= */
function mediaconsult_save_page_parameters_postdata( $post_id ) {
	
    if ( array_key_exists( 'mc_display_page_title', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_display_page_title',
            $_POST['mc_display_page_title']
        );
    }
	
    if ( array_key_exists( 'mc_page_title', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_page_title',
            $_POST['mc_page_title']
        );
    }	
	
	

    if ( array_key_exists( 'mc_display_sidebar', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_display_sidebar',
            $_POST['mc_display_sidebar']
        );
    }
	
	
    if ( array_key_exists( 'mc_slider_type', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_slider_type',
            $_POST['mc_slider_type']
        );
    }
	
    if ( array_key_exists( 'mc_slider_posts_category', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_slider_posts_category',
            $_POST['mc_slider_posts_category']
        );
    }
    	
    if ( array_key_exists( 'mc_sidebar_position', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_sidebar_position',
            $_POST['mc_sidebar_position']
        );
    }
	
    if ( array_key_exists( 'mc_display_slider', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_display_slider',
            $_POST['mc_display_slider']
        );
    }	

    if ( array_key_exists( 'mc_posts_category', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_blog_cat',
            $_POST['mc_posts_category']
        );
    }
	
    if ( array_key_exists( 'mc_display_post_filters', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_display_post_filters',
            $_POST['mc_display_post_filters']
        );
    }
		
    if ( array_key_exists( 'mc_display_ressources_filters', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_display_ressources_filters',
            $_POST['mc_display_ressources_filters']
        );
    }
    		
    if ( array_key_exists( 'mc_post_layout', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_post_layout',
            $_POST['mc_post_layout']
        );
    }
	
    if ( array_key_exists( 'mc_ressources_layout', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_ressource_layout',
            $_POST['mc_ressources_layout']
        );
    }
    		
    if ( array_key_exists( 'mc_portfolio_category', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_port_cat',
            $_POST['mc_portfolio_category']
        );
    }	
	
    if ( array_key_exists( 'mc_ressources_category', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_ressources_cat',
            $_POST['mc_ressources_category']
        );
    }	
	
		
    if ( array_key_exists( 'mc_display_cat', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_display_port_cat',
            $_POST['mc_display_cat']
        );
    }
	
    if ( array_key_exists( 'mc_port_columns', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_mediaconsult_port_columns',
            $_POST['mc_port_columns']
        );
    }	
}
add_action( 'save_post', 'mediaconsult_save_page_parameters_postdata' );


?>