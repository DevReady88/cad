<?php
/*
Plugin Name: MC Custom Metaboxes
Plugin URI: http://www.celestialthemes.com
Description: Media Consult Custom Metaboxes Plugin
Author: Celestial Themes
Author URI: http://www.celestialthemes.com
Version: 1.0
License: GNU General Public License version 2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// Adds Meta Boxes
require_once( dirname(__FILE__) . '/includes/meta-box.php' );