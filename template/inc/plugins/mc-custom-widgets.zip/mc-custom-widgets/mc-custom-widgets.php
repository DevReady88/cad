<?php
/*
Plugin Name: MC Custom Widgets
Plugin URI: http://www.celestialthemes.com
Description: Media Consult Custom Widgets Plugin
Author: Celestial Themes
Author URI: http://www.celestialthemes.com
Version: 1.0
License: GNU General Public License version 2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


// Include the custom widgets
function mediaconsult_custom_widgets() {

	/* register custom recent blog posts widget */
	require_once ( dirname(__FILE__) . '/includes/widgets/widget_recent_posts.php' );
	register_widget( 'mediaconsult_RecentPostsWidget' );	
	
	/* register custom posts categories widget */
	require_once ( dirname(__FILE__) . '/includes/widgets/widget_posts_cat.php' );
	register_widget( 'mediaconsult_PostsCategWidget' );
	
	/* register custom posts categories widget */
	require_once ( dirname(__FILE__) . '/includes/widgets/widget_ressources_posts.php' );
	register_widget( 'mediaconsult_RessourcesPostsWidget' );

}


function mediaconsult_widgets_setup() {

	// Add custom widgets function to the 'widgets_init' action hook.
	add_action( 'widgets_init', 'mediaconsult_custom_widgets' );

}

add_action( 'after_setup_theme', 'mediaconsult_widgets_setup' );