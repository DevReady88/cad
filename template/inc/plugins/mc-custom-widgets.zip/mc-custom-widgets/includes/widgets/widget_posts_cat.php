<?php
/**
 * PostsCategWidget Class
 */
class mediaconsult_PostsCategWidget extends WP_Widget {
    /** constructor */
    public function __construct() {
		
		$widget_ops = array( 'classname' => 'mediaconsult_widget_posts_categories', 'description' => esc_html__( 'Displays your categories from a parent category of your choice.', 'mediaconsult' ) );
		
		parent::__construct( 'mediaconsult_posts_categ' , esc_html__( 'MC Posts Categories', 'mediaconsult' ) , $widget_ops );
		
    }

    /** @see WP_Widget::widget */
    public function widget( $args, $instance ) {		
        extract( $args );
		
		$title = null; 
		$categ_parent = null;
		$categ_parent_id = null;

		
		echo $before_widget;


			/* widget title */
			$title = apply_filters( 'mediaconsult_widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this -> id_base );

			if ( $title ) {
				echo $before_title . esc_html( $title ) . $after_title;
			}

			/* parent category */
			$categ_parent = $instance['parent_category'];

			/* parent category id */
			$categ_parent_id = get_cat_id( htmlentities( $categ_parent ) );  

			/* query */
			$categ_args = array(
				'child_of'          => $categ_parent_id,
				'title_li'			=> '',
				'show_option_none'  => esc_html__( 'No child categories that belong to the parent category you\'ve selected were found.', 'mediaconsult' )
			); ?>


			<ul>
				<?php wp_list_categories( $categ_args ); ?>
			</ul>


		<?php echo $after_widget;
            

    }

	
    /** @see WP_Widget::update */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
	
		// Strip tags to remove HTML (important for text inputs)
		$instance['title'] = strip_tags( $new_instance['title'] );		
		$instance['parent_category'] = $new_instance['parent_category'];
		
		return $instance;
	}
	
	
    /** @see WP_Widget::form */
    public function form( $instance ) {				
        
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				
		$categ_parent = isset( $instance['parent_category'] ) ? esc_attr( $instance['parent_category'] ) : '';

		?>

       
        <p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mediaconsult' ); ?> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</label>
        </p>
            
		<p>
       		<label for="<?php echo esc_attr( $this->get_field_id( 'parent_category' ) ); ?>"><?php esc_html_e( 'Pull your child categories from:', 'mediaconsult' ); ?></label>
        	
			<select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'parent_category' ) ); ?>">                       
				
				<?php $all_categories = get_categories( 'orderby=name' );

					foreach( $all_categories as $category ) {
						
						if( $categ_parent == $category->cat_name ) {		

							echo "<option value='" . $category->cat_name . "' selected='selected'>" . $category->cat_name . "</option>\n";
							
						} else {
							
							echo "<option value='" . $category->cat_name . "'>" . $category->cat_name . "</option>\n";
							
						}
						
					}

				?>    

			</select>
        </p> 
                                                                                                  
                           
        <?php 
    }

} // class mediaconsult_PostsCategWidget

?>