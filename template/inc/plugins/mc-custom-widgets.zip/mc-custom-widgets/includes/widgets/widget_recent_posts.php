<?php
/**
 * BlogWidget Class
 */
class mediaconsult_RecentPostsWidget extends WP_Widget {
    /** constructor */
    public function __construct() {
		
		$widget_ops = array( 'classname' => 'mediaconsult_widget_recent_posts', 'description' => esc_html__( 'Displays Your Latest Blog Posts.', 'mediaconsult' ) );
		
		parent::__construct( 'mediaconsult_recent_posts' , esc_html__( 'MC Recent Blog Posts', 'mediaconsult' ) , $widget_ops );
		
    }

    /** @see WP_Widget::widget */
    public function widget( $args, $instance ) {		
        extract( $args );
		
		$title = null; 
		$blog_posts_no = null;
		$show_comments_no = 'false';
		$all_categ = null;
		$layout_type = null;
		
		
		echo $before_widget;
        
		
		
			/* widget title */
			$title = apply_filters( 'mediaconsult_widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this -> id_base );

			if ( $title ) {
				echo $before_title . esc_html( $title ) . $after_title;
			}

			/* get the current posts number */
			$blog_posts_no = isset( $instance['blog_posts_no'] ) ? (int)$instance['blog_posts_no'] : 3;

			/* display or hide comments number */
			//$show_comments_no = $instance[ 'show_comments_no' ] ? 'true' : 'false';
			//$show_comments_no = $instance['show_comments_no'];
			if (! empty( $instance['show_comments_no'] ) ) { $show_comments_no = $instance['show_comments_no']; }
		
			/* get the current category */
			if (! empty( $instance['all_categ'] ) ) { $all_categ = $instance['all_categ']; }

			/* layout type */
			if (! empty( $instance['layout_type'] ) ) { $layout_type = $instance['layout_type']; }

			/* entire section clickable */
			$block_click_class = '';

			if ( $layout_type == 'text_only' ) {
				$block_click_class = 'block-click';
			}

		
			global $post;

			/* query arguments */
			$mediaconsult_args_posts = array(
					'posts_per_page' 		=> $blog_posts_no,
					'cat'                   => $all_categ,
					'orderby' 				=> 'date',
					'order'   				=> 'DESC',
					'ignore_sticky_posts' 	=> 1
					);
			?>


			<ul class="recentposts-list <?php echo esc_attr( $layout_type ); ?>">

				<?php $mediaconsult_query = new WP_Query( $mediaconsult_args_posts );

				if ( $mediaconsult_query->have_posts() ) {

					while ( $mediaconsult_query->have_posts() ) {

						$mediaconsult_query->the_post(); ?>

						<li class="<?php echo esc_attr( $block_click_class ); ?>">

						<?php if ( has_post_thumbnail() ) { ?>

							<div class="recentposts-image">

								<?php
									echo '<a href="' . get_permalink() . '">';
									echo get_the_post_thumbnail( $post->ID, 'mediaconsult_60x60-crop' );
									echo '</a>';
								?>								

							</div>

							<div class="recentposts-content">

								<h6>
									<a href="<?php esc_url( the_permalink() ); ?>" class="recentposts-title">
										<?php the_title(); ?>
									</a>
								</h6>

								<div class="recentposts-exceprt"><?php echo mediaconsult_excerpt( '12' ); ?></div>

								<span class="recentposts-date"><?php echo esc_html( get_the_date() ); ?></span>

								<?php if( $show_comments_no == 'true' ) : ?>

								<span class="recentposts-comments">
									<a href="<?php esc_url( comments_link() ); ?>">
										<?php echo comments_number(); ?>
									</a>
								</span>

								<?php endif; ?>

							</div>

						<?php } else { ?>

							<div class="recentposts-content recentposts-content-noimg">

								<a href="<?php esc_url( the_permalink() ); ?>" class="recentposts-title">
									<?php the_title(); ?>
								</a>

								<span class="recentposts-date"><?php echo esc_html( get_the_date() ); ?></span>

								<?php if( $show_comments_no == 'true' ) : ?>

								<span class="recentposts-comments">
									<a href="<?php esc_url( comments_link() ); ?>">
										<?php echo comments_number(); ?>
									</a>
								</span>

								<?php endif; ?>

							</div>						

						<?php } ?>

						</li>

					<?php }

					} else { ?>

						<li>

							<p class="textwidget"><?php esc_html_e( 'Sorry, no posts matched your criteria.', 'mediaconsult' ); ?></p>

						</li>

				<?php } ?>

				<?php wp_reset_postdata(); ?>

			</ul> 
                
                      

        <?php echo $after_widget;
            
    }

    /** @see WP_Widget::update */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
	
		// Strip tags to remove HTML (important for text inputs)
		$instance['title'] = strip_tags( $new_instance['title'] );		
		$instance['blog_posts_no'] = $new_instance['blog_posts_no'];
        $instance['all_categ'] = strip_tags($new_instance['all_categ']);
        $instance['show_comments_no'] = $new_instance['show_comments_no'];	
		$instance['layout_type'] = $new_instance['layout_type'];
		
		return $instance;
	}
	
    /** @see WP_Widget::form */
    public function form( $instance ) {				
        
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				
		if ( !isset($instance['blog_posts_no']) || !$blog_posts_no = (int) $instance['blog_posts_no'] ) {
			$blog_posts_no = 3;	
		}
		

        $all_categ = "";
        if( isset( $instance['all_categ'] ) ) {
            $all_categ = $instance['all_categ'];
        }

		
		$show_comments_no = false;
        if( isset( $instance['show_comments_no'] ) ) {
            $show_comments_no = $instance['show_comments_no'];
        }		
		
		
        $layout_type = "";
        if( isset( $instance['layout_type'] ) ) {
            $layout_type = $instance['layout_type'];
        }		

		
        ?>		

            <p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mediaconsult' ); ?> 
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</label>
            </p>
                    
            <p>
            	<label for="<?php echo esc_attr( $this->get_field_id( 'blog_posts_no' ) ); ?>"><?php esc_html_e( 'Number Blog Posts:', 'mediaconsult' ); ?>
		            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('blog_posts_no') ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'blog_posts_no' ) ); ?>" type="text" value="<?php echo esc_attr( $blog_posts_no ); ?>" />
            	</label>
            </p>        
                                               
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'all_categ' ) ); ?>"><?php esc_html_e( 'Categories:', 'mediaconsult' ); ?></label>

				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'all_categ' ) ); ?>">
					<?php

					echo "<option value=''>". esc_html__( 'All', 'mediaconsult' )."</option>\n";

					$all_categories = get_categories( 'orderby=name' );

						foreach( $all_categories as $category ) {
							
							if( $instance['all_categ'] == $category->cat_ID ) {
								echo "<option value='" . esc_attr( $category->cat_ID ) . "' selected='selected'>" . esc_html( $category->cat_name ) . "</option>\n";
							} else {
								echo "<option value='" . esc_attr( $category->cat_ID ) . "'>" . esc_html( $category->cat_name ) . "</option>\n";
							}
							
						}

					?>                 
				</select>

			</p>    
                          
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'layout_type' ) ); ?>"><?php esc_html_e( 'Layout:', 'mediaconsult' ); ?></label>

				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'layout_type' ) ); ?>">
					<?php

					
					$layout_type_options = array( 'default', 'text_only' );
		

					foreach( $layout_type_options as $layout_option ) {
						
						
						if( $instance['layout_type'] == $layout_option ) {

							echo "<option value='" . esc_attr( $layout_option ) . "' selected='selected'>" . esc_html( $layout_option ) . "</option>\n";

						} else {

							echo "<option value='" . esc_attr( $layout_option ) . "'>" . esc_html( $layout_option ) . "</option>\n";

						}
					
						
					}
		
		
					?>                 
				</select>

			</p>
                          
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'show_comments_no' ) ); ?>"><?php esc_html_e( 'Show Comments Number:', 'mediaconsult' ); ?></label>

				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'show_comments_no' ) ); ?>">
					<?php

					
					$comments_number_options = array( 'false', 'true' );
		

					foreach( $comments_number_options as $comments_option ) {
						
						
						if( $instance['show_comments_no'] == $comments_option ) {

							echo "<option value='" . esc_attr( $comments_option ) . "' selected='selected'>" . esc_html( $comments_option ) . "</option>\n";

						} else {

							echo "<option value='" . esc_attr( $comments_option ) . "'>" . esc_html( $comments_option ) . "</option>\n";

						}
					
						
					}
		
		
					?>                 
				</select>

			</p>                                                                             
                           
        <?php 
    }

} // class mediaconsult_RecentPostsWidget

?>