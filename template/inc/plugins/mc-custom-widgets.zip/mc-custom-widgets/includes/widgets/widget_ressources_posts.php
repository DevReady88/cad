<?php
/**
 * BlogWidget Class
 */
class mediaconsult_RessourcesPostsWidget extends WP_Widget {
    /** constructor */
    public function __construct() {
		
		$widget_ops = array( 'classname' => 'mediaconsult_widget_ressources_posts', 'description' => esc_html__( 'Displays Your Latest Ressources Posts.', 'mediaconsult' ) );
		
		parent::__construct( 'mediaconsult_ressources_posts' , esc_html__( 'MC Ressources Posts', 'mediaconsult' ) , $widget_ops );
		
    }

    /** @see WP_Widget::widget */
    public function widget( $args, $instance ) {		
        extract( $args );
		
		$title = null; 
		$ressources_posts_no = null; 
		$all_categ = null; 
		$layout_type = null;
		
		
		echo $before_widget;

		
		
		/* widget title */
		$title = apply_filters( 'mediaconsult_widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this -> id_base );

		if ( $title ) {
			echo $before_title . esc_html( $title ) . $after_title;
		}

		/* get the current posts number */
		$ressources_posts_no = isset( $instance['ressources_posts_no'] ) ? (int)$instance['ressources_posts_no'] : 3;

		/* get the current category */
		if (! empty( $instance['all_categ'] ) ) { $all_categ = $instance['all_categ']; }

		/* layout type */
		if (! empty( $instance['layout_type'] ) ) { $layout_type = $instance['layout_type']; }


		$block_click_class = '';

		if ( ! empty( $instance['layout_type'] ) && $instance['layout_type'] == 'text_only' ) {
			$block_click_class = 'block-click';
		}

		global $post;

		/* query arguments */
		if ( ! empty( $instance['all_categ'] ) && $instance['all_categ'] ) {

			$mediaconsult_args_posts = array(
				'post_type'				=> 'ressources',
				'tax_query' => array(
					array(
						'taxonomy' => 'ressources_category',
						'terms' => $instance['all_categ'],
						'field' => 'term_id',
					)
				),			
				'posts_per_page' 		=> $ressources_posts_no,
				'orderby' 				=> 'date',
				'order'   				=> 'DESC',
				'ignore_sticky_posts' 	=> 1
			);

		} else {

			$mediaconsult_args_posts = array(
				'post_type'				=> 'ressources',		
				'posts_per_page' 		=> $ressources_posts_no,
				'orderby' 				=> 'date',
				'order'   				=> 'DESC',
				'ignore_sticky_posts' 	=> 1
			);

		}

		?>
               
			<ul class="recentposts-list <?php echo esc_attr( $layout_type ); ?>">

				<?php $mediaconsult_query = new WP_Query( $mediaconsult_args_posts );

				if ( $mediaconsult_query->have_posts() ) {

					while ( $mediaconsult_query->have_posts() ) {

						$mediaconsult_query->the_post(); ?>

						<li class="<?php echo esc_attr( $block_click_class ); ?>">
						
						<?php if ( has_post_thumbnail() ) { ?>
							
							<div class="recentposts-image">
								
								<?php
									echo '<a href="' . get_permalink() . '">';
									echo get_the_post_thumbnail( $post->ID, 'mediaconsult_60x60-crop' );
									echo '</a>';
								?>								
								
							</div>
							
							<div class="recentposts-content">
							
								<h6>
									<a href="<?php esc_url( the_permalink() ); ?>" class="recentposts-title">
										<?php the_title(); ?>
									</a>
								</h6>
								
								<div class="recentposts-exceprt"><?php echo mediaconsult_excerpt( '12' ); ?></div>
								
								<span class="recentposts-date small-secondary"><?php echo esc_html( get_the_date() ); ?></span>
								
							</div>
							
						<?php } else { ?>
						
							<div class="recentposts-content recentposts-content-noimg">
							
								<a href="<?php esc_url( the_permalink() ); ?>" class="recentposts-title">
									<?php the_title(); ?>
								</a>

								<span class="recentposts-date small-secondary"><?php echo esc_html( get_the_date() ); ?></span>
								
							</div>						
						
						<?php } ?>
							
						</li>

					<?php }

					} else { ?>

						<li>

							<p class="textwidget"><?php esc_html_e( 'Sorry, no posts matched your criteria.', 'mediaconsult' ); ?></p>

						</li>

				<?php } ?>

				<?php wp_reset_postdata(); ?>

			</ul> 
                
                      

            <?php echo $after_widget; ?>
            
        <?php
    }

    /** @see WP_Widget::update */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
	
		// Strip tags to remove HTML (important for text inputs)
		$instance['title'] = strip_tags( $new_instance['title'] );		
		$instance['ressources_posts_no'] = $new_instance['ressources_posts_no'];
        $instance['all_categ'] = strip_tags($new_instance['all_categ']);
		$instance['layout_type'] = $new_instance['layout_type'];
		
		return $instance;
	}
	
    /** @see WP_Widget::form */
    public function form( $instance ) {
        
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				
		if ( !isset($instance['ressources_posts_no']) || !$ressources_posts_no = (int) $instance['ressources_posts_no'] ) {
			$ressources_posts_no = 3;	
		}
		

        $all_categ = "";
        if( isset( $instance['all_categ'] ) ) {
            $all_categ = $instance['all_categ'];
        }	
		
		
        $layout_type = "";
        if( isset( $instance['layout_type'] ) ) {
            $layout_type = $instance['layout_type'];
        }	


        ?>		

            <p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mediaconsult' ); ?> 
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</label>
            </p>
                    
            <p>
            	<label for="<?php echo esc_attr( $this->get_field_id( 'ressources_posts_no' ) ); ?>"><?php esc_html_e( 'Number Ressource Posts:', 'mediaconsult' ); ?>
		            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('ressources_posts_no') ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'ressources_posts_no' ) ); ?>" type="text" value="<?php echo esc_attr( $ressources_posts_no ); ?>" />
            	</label>
            </p>        
                                               
			<p>
				<?php $mediaconsult_taxonomies = get_object_taxonomies( 'ressources' ); ?>
				
				<label for="<?php echo esc_attr( $this->get_field_id( 'all_categ' ) ); ?>"><?php esc_html_e( 'Categories:', 'mediaconsult' ); ?></label>

				<select name="<?php echo esc_attr( $this->get_field_name( 'all_categ' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'all_categ' ) ); ?>" class="widefat">
					
					<option value=""><?php esc_html_e( 'All', 'mediaconsult' ); ?></option>
					
					<?php
		
					foreach ( $mediaconsult_taxonomies as $mediaconsult_taxonomy ) {     

						$terms = get_terms ( 'ressources_category' );

						if ( !empty( $terms ) ) {

							foreach ( $terms as $term ) { ?>
							
								<option <?php selected( $all_categ, $term->term_id ); ?> value="<?php echo esc_attr( $term->term_id ); ?>"><?php echo esc_html( $term->name ); ?></option>
						
							<?php }

						}
					}
		
					?>
					
				</select>

			</p>    

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'layout_type' ) ); ?>"><?php esc_html_e( 'Layout:', 'mediaconsult' ); ?></label>

				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'layout_type' ) ); ?>">
					
					<?php $layout_type_options = array( 'default', 'text_only' );
		
					foreach( $layout_type_options as $layout_option ) {
						
						
						if( $instance['layout_type'] == $layout_option ) {

							echo "<option value='" . esc_attr( $layout_option ) . "' selected='selected'>" . esc_html( $layout_option ) . "</option>\n";

						} else {

							echo "<option value='" . esc_attr( $layout_option ) . "'>" . esc_html( $layout_option ) . "</option>\n";

						}
					
					} ?>                
				</select>
			</p>                                                                           
                           
        <?php 
    }

} // class mediaconsult_RessourcesPostsWidget

?>